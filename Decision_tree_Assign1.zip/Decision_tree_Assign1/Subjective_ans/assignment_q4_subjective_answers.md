# for real input and  real output

- MSE- fit 5.69285435410633  
- MSE- predict 8.917084747943654e-07

![](../imgs/Q4/RR/hm_fit.png)
![](../imgs/Q4/RR/hm_predict.png)
![](../imgs/Q4/RR/model_comparision_fit.png)
![](../imgs/Q4/RR/model_comparision_predict.png)



# for discrete input and  discrete output

- MSE- fit 0.05830230833728385  
- MSE- predict 5.909952630501817e-05

![](../imgs/Q4/DD/hm_fit.png)
![](../imgs/Q4/DD/hm_predict.png)
![](../imgs/Q4/DD/model_comparision_fit.png)
![](../imgs/Q4/DD/model_comparision_predict.png)


# for discrete input and  real output

- MSE- fit 2.2300657757448823  
- MSE- predict 1.3064419493858032e-05

![](../imgs/Q4/DR/hm_fit.png)
![](../imgs/Q4/DR/hm_predict.png)
![](../imgs/Q4/DR/model_comparision_fit.png)
![](../imgs/Q4/DR/model_comparision_predict.png)


# for real input and  discrete output

- MSE- fit 2.2768845646967892  
- MSE- predict 9.846790865259736e-07

![](../imgs/Q4/RD/hm_fit.png)
![](../imgs/Q4/RD/hm_predict.png)
![](../imgs/Q4/RD/model_comparision_fit.png)
![](../imgs/Q4/RD/model_comparision_predict.png)